import { Handler, Context, Callback } from 'aws-lambda';
import { createNestApplication } from './main';

let cachedHandler: Handler;

export const handler: Handler = async (event, context: Context, callback: Callback) => {
  if (!cachedHandler) {
    const app = await createNestApplication();
    cachedHandler = app;
  }
  return cachedHandler(event, context, callback);
};
